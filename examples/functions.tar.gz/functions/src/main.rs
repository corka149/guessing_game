fn main() {
    let x = another_function();

    println!("The value of x is: {}", x);
}

fn another_function() -> i32 {
    5
}