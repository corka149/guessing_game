fn main() {
    let byte1 = b'a';
    let byte2 = b' ';
    println!("'{}','{}'",byte1, byte2);
}

fn first_word(s: &String) -> usize {
    let bytes = s.as_bytes();

    for (i, &item) in bytes.iter().enumerate() { // iter returns each element in a collection
        if item == b' ' {                         // b' ' = byte literal syntax
            return i;           
        }
    }

    s.len()
}