fn main() {
    let s1 = String::from("Hello");
    let s2 = s1;

    println!("{}", s1);
}
